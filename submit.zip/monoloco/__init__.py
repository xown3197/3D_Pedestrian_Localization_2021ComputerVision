
"""Open implementation of MonoLoco."""

__version__ = '0.4.9'
